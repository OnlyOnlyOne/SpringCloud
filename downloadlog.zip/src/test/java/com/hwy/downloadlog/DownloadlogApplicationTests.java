package com.hwy.downloadlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DownloadlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
