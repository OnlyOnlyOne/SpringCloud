package com.hwy.downloadlog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DownloadlogApplication {

    public static void main(String[] args) {
        SpringApplication.run(DownloadlogApplication.class, args);
    }

}
