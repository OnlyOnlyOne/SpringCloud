package com.hwy.downloadlog.controller;
import ch.qos.logback.core.util.FileUtil;
import org.apache.commons.io.FileUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import sun.java2d.pipe.BufferedTextPipe;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;

import java.io.*;
import java.net.URLEncoder;
import java.nio.file.FileSystem;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@RestController
public class LogController {
    @GetMapping("/downloadlog/getlog")
    public ResponseEntity<byte[]> getLog(@RequestParam String p, HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("p:" + p);
        //获得文件名字
        int index = p.lastIndexOf("/");
        String fileName = p.substring(index);
        //获取项目部署在服务器的路径
//        String path = request.getServletContext().getRealPath("/");
//        String downPath = path + p;
//        System.out.println("downPath:"+downPath);
        File file = new File(p);
        if(file.exists()){
            //转换为zip文件
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.setContentDispositionFormData("attchment",fileName);
            httpHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file),httpHeaders, HttpStatus.OK);
        }
            return ResponseEntity.notFound().build();

    }
}
